package azkaban.jobcallback;

public enum JobCallbackStatusEnum {
  STARTED, SUCCESS, FAILURE, COMPLETED
}
