This module is the contract between azkaban and dependency plugin. It mainly contains minimal set of the interfaces needed by flow trigger dependency plugin development. 
